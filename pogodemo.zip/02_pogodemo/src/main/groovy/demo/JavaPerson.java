package demo;

public class JavaPerson {
}
