package demo

class GroovyPerson {
}
