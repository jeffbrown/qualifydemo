package demo

import spock.lang.Specification

class GroovyPersonSpec extends Specification {

    void 'test Groovy Person'() {
        when:
	def person = new GroovyPerson()

	then:
	person.firstName == null
	person.lastName == null

	when:
	person = new GroovyPerson(firstName: 'Robert', lastName: 'Fripp')

	then:
	person.firstName == 'Robert'
	person.lastName == 'Fripp'
	person.fullName == 'Robert Fripp'

	when:
	person.firstName = 'Adrian'
	person.lastName = 'Belew'

	then:
	person.firstName == 'Adrian'
	person.lastName == 'Belew'
	person.fullName == 'Adrian Belew'
    }

    /**
     * No additional work needs to be done to make the next two tests pass
     * If the first test passes, these will pass too.
     * These tests demo additional capabilities of Groovy.
     */

    void 'demo reordering'() {

        when: 'Reordering field args'
        def person = new GroovyPerson(lastName: 'McCartney', firstName: 'Paul')

        then: 'It works!'
        person.firstName == 'Paul'
        person.lastName == 'McCartney'
        person.fullName == 'Paul McCartney'
    }

    void 'demo Map constructor'() {

        when: 'Using Map constructor'
        def person = new GroovyPerson([firstName: 'Paul', lastName: 'McCartney'])

        then: 'This also works'
        person.firstName == 'Paul'
        person.lastName == 'McCartney'
        person.fullName == 'Paul McCartney'
    }
}
