package demo

import spock.lang.Specification

class JavaPersonSpec extends Specification {

    void 'test Java Person'() {

        when:
        def person = new JavaPerson()

	then:
	person.firstName == null
	person.lastName == null

	when:
	person = new JavaPerson('Robert', 'Fripp')

	then:
	person.firstName == 'Robert'
	person.lastName == 'Fripp'
	person.fullName == 'Robert Fripp'

	when:
	person.firstName = 'Adrian'
	person.lastName = 'Belew'

	then:
	person.firstName == 'Adrian'
	person.lastName == 'Belew'
	person.fullName == 'Adrian Belew'
    }

    /**
     * No additional work is needed to make this test pass.
     * It is here for comparison.
     * Java, without named parameters, does not have a mechanism
     * for freely ordering them.
     */

    void 'test Java params cannot be reordered'() {

        when: 'Name is out of order'
        def person = new JavaPerson('Lennon', 'John')

        then: 'Name is incorrect'
        person.firstName != 'John'
        person.lastName != 'Lennon'
    }

}
