package demo

class Person {
    String firstName
    String lastName
    Integer age
}
