import demo.Person

class BootStrap {

    def init = { servletContext ->
    def peopleData = []
        peopleData << [firstName: 'Geddy', lastName: 'Lee', age: 62]
        peopleData << [firstName: 'Alex', lastName: 'Lifeson', age: 62]
        peopleData << [firstName: 'Neil', lastName: 'Peart', age: 62]
        peopleData << [firstName: 'Zack', lastName: 'Brown', age: 18]
        peopleData << [firstName: 'Jake', lastName: 'Brown', age: 15]

        peopleData.each { personMap ->
            new Person(personMap).save()
        }
    }
    def destroy = {
    }
}
