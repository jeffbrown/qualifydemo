package demo

import geb.spock.GebSpec
import grails.test.mixin.integration.Integration

@Integration
class PersonCrudFunctionalSpec extends GebSpec {

    void "test a person older than 120 years old"() {
        when:
        go '/person/create'
        def form = $('form')
        form.age = '135'
        form.firstName = 'Grandpa'
        form.lastName = 'Brown'
        form.create().click()

        then:
        $('li', 'data-field-id':'age').text() == 'Age [135] is invalid. The maximum allowed age is 120.'
    }

    void "test a person younger than 1 year old"() {
        when:
        go '/person/create'
        def form = $('form')
        form.age = '0'
        form.firstName = 'Baby'
        form.lastName = 'Brown'
        form.create().click()

        then:
        $('li', 'data-field-id':'age').text() == 'Age [0] is invalid. The minimum allowed age is 1.'
    }
}
