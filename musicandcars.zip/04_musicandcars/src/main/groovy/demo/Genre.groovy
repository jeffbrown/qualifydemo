package demo

enum Genre {
    ROCK, PROGRESSIVE_ROCK, BLUES, HEAVY_METAL
}
