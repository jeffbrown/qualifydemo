package demo

import grails.test.mixin.integration.Integration
import grails.web.mime.MimeType
import groovyx.net.http.ContentType
import groovyx.net.http.RESTClient
import org.springframework.http.HttpStatus
import spock.lang.Shared
import spock.lang.Specification
import spock.lang.Stepwise

@Integration
@Stepwise
class CarFunctionalSpec extends Specification {

    @Shared
    def rest = new RESTClient('http://localhost:8080/')

    void "test that no cars exist"() {
        when:
        def resp = rest.get(path: 'automobiles')

        then:
        resp.status == HttpStatus.OK.value()
        resp.contentType == MimeType.JSON.name
        resp.data.size() == 0
    }

    void "test creating a car"() {
        when:
        def resp = rest.post(path: 'automobiles',
                body: [make: 'Chevy', model: 'Equinox'],
                requestContentType: ContentType.JSON)

        then:
        resp.status == HttpStatus.CREATED.value()
        resp.contentType == 'application/json'
        resp.data.make == 'Chevy'
        resp.data.model == 'Equinox'

        when:
        resp = rest.post(path: 'automobiles',
                         body: [make: 'Ford', model: 'Fusion'],
                         requestContentType: ContentType.JSON)

        then:
        resp.status == HttpStatus.CREATED.value()
        resp.contentType == 'application/json'

        and:
        resp.data.make == 'Ford'
        resp.data.model == 'Fusion'
    }

    void 'test retrieving list of cars defaults to JSON'() {
        when:
        def resp = rest.get(path: 'automobiles')

        then:
        resp.status == HttpStatus.OK.value()
        resp.contentType == MimeType.JSON.name
        resp.data.size() == 2

        and:
        resp.data[0].make == 'Chevy'
        resp.data[0].model == 'Equinox'

        and:
        resp.data[1].make == 'Ford'
        resp.data[1].model == 'Fusion'

    }

    void 'test retrieving list of cars as JSON'() {
        when:
        def resp = rest.get(path: 'automobiles.json')

        then:
        resp.status == HttpStatus.OK.value()
        resp.contentType == MimeType.JSON.name
        resp.data.size() == 2

        and:
        resp.data[0].make == 'Chevy'
        resp.data[0].model == 'Equinox'

        and:
        resp.data[1].make == 'Ford'
        resp.data[1].model == 'Fusion'
    }

    void 'test retrieving list of cars as XML'() {
        when:
        def resp = rest.get(path: 'automobiles.xml')

        then:
        resp.status == HttpStatus.OK.value()
        resp.contentType == MimeType.TEXT_XML.name
        resp.data.car.size() == 2

        and:
        resp.data.car[0].make.text() == 'Chevy'
        resp.data.car[0].model.text() == 'Equinox'

        and:
        resp.data.car[1].make.text() == 'Ford'
        resp.data.car[1].model.text() == 'Fusion'
    }
}
